package main

import (
	"fmt"
	"time"
)

func main() {
	fmt.Println("Go rules, Jordan drools!")
	time.Sleep(15 * time.Second)
}
